import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'simple-project-ui';
  proId:any;
  isProjectChanged:any;
  getSiteById(event){
   this.proId=event;
  }

  getProjects(event){
    this.isProjectChanged=event;
  }
}
