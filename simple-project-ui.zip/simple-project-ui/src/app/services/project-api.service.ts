import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SiteDetails } from '../model/site-model';

@Injectable({
  providedIn: 'root'
})
export class ProjectApiService {
  projectList: any;
  readonly baseURL = 'http://localhost:3000/ProjectDetails';
  readonly baseSiteURL = 'http://localhost:3000/SiteDetails';
  
  constructor(private http: HttpClient) { }

  addProjet(project: any) {
    return this.http.post(this.baseURL, project);
  }

  getProjects() {
    return this.http.get(this.baseURL);
  }

  addSiteInfo(siteInfo: SiteDetails) {
    return this.http.post(this.baseSiteURL+"/addSiteInfo", siteInfo);
  }
  getSites(){
    return this.http.get(this.baseSiteURL);
  }

  getSiteById(id:any){
    return this.http.get(this.baseSiteURL+"/"+id);
  }
  updateSiteInfo(site: SiteDetails){
    return this.http.put(this.baseSiteURL+`/${site._id}`,site);
  }

}


