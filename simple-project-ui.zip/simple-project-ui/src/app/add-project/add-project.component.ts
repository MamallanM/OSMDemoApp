import { Component, EventEmitter, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { ProjectApiService } from '../services/project-api.service';
import { ToastrService } from 'ngx-toastr';
import { Output } from '@angular/core';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit,OnDestroy {
  projectForm:FormGroup;
  submitted:boolean=false;
  projectList:any=[];
  projectItem:any;
  private projSub:Subscription;
  private sitebyID:Subscription;
  @Output() valuechanged=new EventEmitter();
  @Output() projectlistchanged=new EventEmitter();

  constructor(private formBuilder: FormBuilder,private projService:ProjectApiService,
    private toastr:ToastrService) { }

  ngOnInit(): void {
   // this.projectItem = "";
    this.projectForm = this.formBuilder.group({
      projectId: [''],
      projectName: ['',Validators.required],
      projectDesc: ['']
    });
   
    this.getProjects();
  }
  get u(){
    return this.projectForm.controls;
  }


  onSubmit() {
    this.submitted=true;
    if(!this.projectForm.valid)
    return;
    var formData=this.projectForm.value;
    
    this.projSub=this.projService.addProjet(formData).subscribe((res) => {
        this.toastr.success("Record saved successfully", "Save")
        this.resetForm();
        this.getProjects(); 
        
      });
  
  }
  projectChange(event){
    this.valuechanged.emit(event);
  }
  projectListChange(event){
    this.projectlistchanged.emit(event);
  }

  getProjects(){
    this.projSub=this.projService.getProjects().subscribe((res) => {
      this.projectItem = "";
     this.projectList=res;
     this.projService.projectList = res;
     this.projectListChange(res);
    });
  }
  resetForm() {
    this.projectForm.reset();
    this.submitted=false;
  }
  
  ngOnDestroy(){
    if(this.projSub){
        this.projSub.unsubscribe();
      }
      }
}
