export class SiteDetails {
    _id:string;
    projectId:number;
    projectName:string;
    siteName:string;
    lat:number;
    long:number;
}
