
	import { Component, ElementRef, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
  import { FormBuilder, FormGroup, Validators } from '@angular/forms';
  import { Subscription } from 'rxjs';
  import { ProjectApiService } from '../services/project-api.service';
  import { ToastrService } from 'ngx-toastr';
  declare var ol: any;
  import { toLonLat } from 'ol/proj';

  
  @Component({
    selector: 'app-add-edit-site',
    templateUrl: './add-edit-site.component.html',
    styleUrls: ['./add-edit-site.component.css']
  })
  export class AddEditSiteComponent implements OnInit {
  
    siteForm: FormGroup;
    submitted: boolean = false;
    isAddForm:boolean=true;
    projectList: any = [];
    siteList: any = [];
    selectedProject:any={};
    projectItem: any;
   @Input('ProjectId') 
    set ProjectId(val:any){
      this.isAddForm=true;
      if(val!=undefined){
      this.selectedProject=val;
      this.getProjects();
      this.getSiteById(val.projectId);
      }
    }
    
  @Input('isProchange') 
    set isProchange(val:any){
       this.projectList = this.projService.projectList;
    }
    overlay: any;
    closer: any;
    map: any;
    private siteSub: Subscription;
    private siteSubInfo: Subscription;
    constructor(private formBuilder: FormBuilder, private projService: ProjectApiService,
      private toastr: ToastrService) { }

    
    
    ngOnInit(): void {
      const numericNumberReg= '^-?[0-9]\\d*(\\.\\d{1,30})?$';//"^[0-9]*$"
      this.siteForm = this.formBuilder.group({
        _id: [''],
        projectId: ['', Validators.required],
        projectName: [''],
        siteName: ['', Validators.required],
        lat: ['', Validators.compose([Validators.required,Validators.pattern(numericNumberReg)])],
        long: ['', Validators.compose([Validators.required,Validators.pattern(numericNumberReg)])],
      });
      this.getProjects();
      this.getSites();
    }
  
    createMap() {
      this.closer = document.getElementById('popup-closer');
      var attribution = new ol.control.Attribution({
        collapsible: false
      });
      this.map = new ol.Map({
        controls: ol.control.defaults({ attribution: false }).extend([attribution]),
        layers: [
          new ol.layer.Tile({
            source: new ol.source.OSM({
              url: 'https://tile.openstreetmap.be/osmbe/{z}/{x}/{y}.png',
              attributions: [ol.source.OSM.ATTRIBUTION, 'Tiles courtesy of <a href="https://geo6.be/">GEO-6</a>'],
              maxZoom: 18
            })
          })
        ],
        target: 'map',
        view: new ol.View({
          center: ol.proj.fromLonLat([4.35247, 50.84673]),
          maxZoom: 18,
          zoom: 12
        })
      });
      /*
      
      */
      //Marker will come here
  
       this.addMarkerElement();
       this.overlay=this.addPopupElement(); 
    
      var overlay1 = this.overlay;
      this.map.addOverlay(this.overlay);
      //popup Design
      var closer = document.getElementById('popup-closer');
      this.closer.onclick = function () {
        overlay1.setPosition(undefined);
        closer.blur();
        return false;
      };
  
     var mapObj=this.map;
     var editSite=this.editSite;
     var addSite=this.addSite;
     var self=this;
     this.map.on('singleclick', function (event) {
      self.resetForm();
        if (mapObj.hasFeatureAtPixel(event.pixel) === true) {
  
          var feature = mapObj.forEachFeatureAtPixel(event.pixel, function (feat, layer) {     
           return feat;  
         }
         );
          var coordinate = event.coordinate;   
          var ll=feature.get('idmm');
          if(ll==undefined){
            var latlong = toLonLat(coordinate);
            var lng={"lat":latlong[0],"long":latlong[1]};
            self.reverseGeocode(lng,function(data){
              var content1 = document.getElementById('popup-content');
              var state=(data.address.state==undefined)?data.address.country:data.address.state;
              var town=(data.address.town==undefined)?"":data.address.town;
              content1.innerHTML = '<div><div style="text-align:center">'+state+',</div> <div style="text-align:center">'+town+'</div><div><b> Lat</b> : ' + lng.lat + '   </div> <div> <b> Long</b> : ' + lng.long + ' <a style= "cursor: pointer;float:right; color:blue; text-decoration:underline;" id="mapadd" target="_blank">Add</a></div>' +
                '</div>';
              overlay1.setPosition(coordinate);
              var anchorTag = document.getElementById('mapadd');
              anchorTag.addEventListener('click',function(event){
                addSite(lng,state,town,self);
              });
            });
          }
          else{

            var content1 = document.getElementById('popup-content');
            var add = ll.siteName.split(",");
            var state = "";
            var town = "";
            if(add.length >=2){
state = add[0];
town = add[1];
            }else{
              state = add[0];
            }
            content1.innerHTML = '<div><div style="text-align:center">'+state+',</div> <div style="text-align:center">'+town+'</div><div><b> Lat</b> : ' + ll.lat + '   </div> <div> <b> Long</b> : ' + ll.long + ' <a style= "cursor: pointer;float:right; color:blue; text-decoration:underline;" id="mapedit" target="_blank">Edit</a></div>' +
              '<div><b>Project Name: </b>'+ ll.projectName+'<div> </div>';
            overlay1.setPosition(coordinate);
            var anchorTag = document.getElementById('mapedit');
            anchorTag.addEventListener('click',function(event){
              editSite(ll,self);
            });

         /* self.reverseGeocode(ll,function(data){
            var content1 = document.getElementById('popup-content');
            var state=(data.address.state==undefined)?data.address.country:data.address.state;
              var town=(data.address.town==undefined)?"":data.address.town;
            content1.innerHTML = '<div><div style="text-align:center">'+state+',</div> <div style="text-align:center">'+town+'</div><div><b> Lat</b> : ' + ll.lat + '   </div> <div> <b> Long</b> : ' + ll.long + ' <a style= "cursor: pointer;float:right; color:blue; text-decoration:underline;" id="mapedit" target="_blank">Edit</a></div>' +
              '<div><b>Project Name: </b>'+ ll.projectName+'<div> </div>';
            overlay1.setPosition(coordinate);
            var anchorTag = document.getElementById('mapedit');
            anchorTag.addEventListener('click',function(event){
              editSite(ll,self);
            });
          });*/
        }
          

        } else {
          var coordinate = event.coordinate;
          var latlong = toLonLat(coordinate);
          self.addMarketDefult(latlong,self);;
          var lng={"lat":latlong[0],"long":latlong[1]};
          self.reverseGeocode(lng,function(data){
            var content1 = document.getElementById('popup-content');
            var state=(data.address.state==undefined)?data.address.country:data.address.state;
              var town=(data.address.town==undefined)?"":data.address.town;
            content1.innerHTML = '<div><div style="text-align:center">'+state+',</div> <div style="text-align:center">'+town+'</div><div><b> Lat</b> : ' + lng.lat + '   </div> <div> <b> Long</b> : ' + lng.long + ' <a style= "cursor: pointer;float:right; color:blue; text-decoration:underline;" id="mapadd" target="_blank">Add</a></div>' +
              '</div>';
            overlay1.setPosition(coordinate);
            var anchorTag = document.getElementById('mapadd');
            anchorTag.addEventListener('click',function(event){
              addSite(lng,state,town,self);
            });
          });
          overlay1.setPosition(coordinate);
          // var closer = document.getElementById('popup-closer');
          // closer.blur();
        }
      });
      
      // var content = document.getElementById('popup-content');
      // content.innerHTML = '<b>Hello world!</b><br />I am a popup.';
      // //content= '<b>Hello world!</b><br />I am a popup.';
      // this.overlay.setPosition(ol.proj.fromLonLat([4.35247, 50.84673]));
    }
  
    reverseGeocode(coords,callback) {
      debugger;
      fetch('http://nominatim.openstreetmap.org/reverse?format=json&lon=' + coords.lat + '&lat=' + coords.long)
        .then(function(response) {
               return response.json();
           }).then(function(json) {
              callback(json);
               console.log(json);
           });
   }
    editSite(rowData,scope){
      scope.isAddForm=false;
      rowData.projectId=scope.getProjectbyId(rowData.projectId);
      scope.siteForm.patchValue(rowData);
    }
    
    
    addSite(rowData,state,town,scope){
      scope.isAddForm=true;
      scope.siteForm.reset();
      var tFormData={};
      if(scope.selectedProject!=null && scope.selectedProject.projectId!=null){
        tFormData["projectId"]=scope.getProjectbyId(scope.selectedProject.projectId);
        tFormData["projectName"]=scope.selectedProject.projectName;
      }else{
        tFormData["projectId"] = "";
      }
      var siteName = state;
      if(town!=null&&town!=''){
        siteName += ", "+town;
      }
      tFormData["siteName"]=siteName;
      tFormData["lat"]=rowData.lat;
      tFormData["long"]=rowData.long;
      scope.siteForm.patchValue(tFormData);
    }
    getProjectbyId(id){
     let project= this.projectList.find(function(x){
       if(x.projectId == id)
       return x;
     })
      return project;
    }

    getSiteById(id){
      var self=this;
     this.projService.getSiteById(id).subscribe((res) => {
       debugger;
        this.siteList = res;
        this.clearMap();
         this.createMap();
      });
    }
    getIconStyle(){
      var iconStyle = new ol.style.Style({
        image: new ol.style.Icon(/** @type {olx.style.IconOptions} */({
          anchor: [0.5, 46],
          anchorXUnits: 'fraction',
          anchorYUnits: 'pixels',
          opacity: 0.75,
          src: 'https://raw.githubusercontent.com/jonataswalker/map-utils/master/images/marker.png'
        }))
      });
      return iconStyle;
    }

    addMarketDefult(coordinate,scope){
      var layer = new ol.layer.Vector({
        source: new ol.source.Vector({
          features: [
            new ol.Feature({
              geometry: new ol.geom.Point(ol.proj.fromLonLat([coordinate[0],coordinate[1]])),
            })
          ]
        }),
        style: scope.getIconStyle(),
      });
      this.map.addLayer(layer);
    }
    addMarkerElement() {
      var self=this;
     
      var marker=this.siteList;
      
      var iconStyle=this.getIconStyle();
    var len=marker.length;
    //layer.destroyFeatures();
      for (var i = 0; i < len; i++) {
        var markerObj=marker[i];
      var layer = new ol.layer.Vector({
        source: new ol.source.Vector({
          features: [
            new ol.Feature({
              geometry: new ol.geom.Point(ol.proj.fromLonLat([markerObj.lat,markerObj.long])),
              idmm: markerObj
            })
          ]
        }),
        style: iconStyle,
      });
      this.map.addLayer(layer);
if(i==0 || i == Math.round(len/2) ){
  this.map.setView(new ol.View({
    center: ol.proj.fromLonLat([markerObj.lat, markerObj.long]),
    //maxZoom: 18,
        zoom: 10
}));
}
      
  
      }
     // this.map.on("click",this.popupCallback);
    }

    removeMapLayer(scope){
     // console.log(this.map);
      //this.map.vectorLayer.getSource().clear();
      this.map.getLayers().forEach(function(layer) 
      {
        scope.map.removeLayer(layer);  
      });
    }
  
    clearMap(){
      document.getElementById('map').innerHTML="";
      document.getElementById('map').innerHTML='<div id="popup" class="ol-popup" style="background-color: white;box-shadow: 0 1px 4px rgba(0,0,0,0.2);padding: 15px;border-radius: 10px;border: 1px solid #cccccc;bottom: 12px;left: -50px;min-width: 280px;"><a href="#" id="popup-closer" class="ol-popup-closer"></a><div id="popup-content"></div></div>'
    
    }
    addPopupElement() {
      var container = document.getElementById('popup');
      this.overlay = new ol.Overlay({
        element: container,
        autoPan: true,
        autoPanAnimation: {
          duration: 250
        }
      });
      return this.overlay;
    }
    get s() {
      return this.siteForm.controls;
    }
  
    onSubmit() {
      this.submitted = true;
      this.siteForm.value.projectId=this.projectItem.projectId;
      this.siteForm.value.projectName=this.projectItem.projectName;
      if (!this.siteForm.valid)
        return;
      var formData = this.siteForm.value;
  
      this.siteSub = this.projService.addSiteInfo(formData).subscribe((res) => {
        if(this.selectedProject!=null && this.selectedProject.projectId!=null){

        this.getSiteById(this.selectedProject.projectId);
        }else{
          this.getSites();
        }
        this.toastr.success("Site Info saved successfully", "Success")
        this.resetForm();
      });
  
    }
    onUpdate(){
      this.submitted = true;
      this.siteForm.value.projectId=this.projectItem.projectId;
      this.siteForm.value.projectName=this.projectItem.projectName;
      if (!this.siteForm.valid)
        return;
      var formData = this.siteForm.value;
  
      this.siteSub = this.projService.updateSiteInfo(formData).subscribe((res) => {
        if(this.selectedProject!=null && this.selectedProject.projectId!=null){

          this.getSiteById(this.selectedProject.projectId);
          }else{
            this.getSites();
          }
        this.toastr.success("Site Info updated successfully", "Success");
        this.resetForm();
      });
    }
    getProjects() {
      this.siteSub = this.projService.getProjects().subscribe((res) => {
        this.projectList = res;
      });
    }
  
    getSites(){
      var self=this;
      this.siteSubInfo = this.projService.getSites().subscribe((res) => {
        this.siteList = res;
         this.clearMap();
         this.createMap();
      });
    }
    resetForm() {
      this.siteForm.reset();
      this.siteForm.controls.projectId.setValue('');
      this.isAddForm=true;
      this.submitted = false;
    }
  
    ngOnDestroy() {
      if (this.siteSub) {
        this.siteSub.unsubscribe();
      }
      if(this.siteSubInfo){
        this.siteSubInfo.unsubscribe();
      }
    }
  }
  
  